﻿// W8449
// April 1, 2018
// CIS199-01
// Lab 7
// This lab explores the creation of a value-returning method. Preconditions and postconditions will also be introduced.
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab7
{
    public partial class Lab7 : Form
    {
        public Lab7()
        {
            InitializeComponent();
        }
        private static double CalcPresentValue(double F, double r, int n)
        {
            return F / Math.Pow(1 + r, n); // Perform the calculation and return the result
            // Precondition: must be included before anything else or it will not work
        }
        private void calculateButton_Click(object sender, EventArgs e)
        {
            double F = double.Parse(futureValueInput.Text); // Gets the text input as a string and cast it as a double
            double r = double.Parse(interestRateInput.Text); // Gets the text input as a string and cast it as a double
            int n = Int32.Parse(numYearsInput.Text); // Gets the text input as a string and cast it as an integer
            string res = Math.Round(CalcPresentValue(F, r, n), 2).ToString(); // Postcondition: Calls function, rounds the result to 2 decimal places, and convert it into a string
            presentValueOutput.Text = "$" + res; // Adds the $ symbol to the Present Value result
        }
    }
}

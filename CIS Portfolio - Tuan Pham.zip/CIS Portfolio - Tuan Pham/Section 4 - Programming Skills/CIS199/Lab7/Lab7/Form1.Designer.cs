﻿namespace Lab7
{
    partial class Lab7
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.futureValueLabel = new System.Windows.Forms.Label();
            this.interestRateLabel = new System.Windows.Forms.Label();
            this.numYearsLabel = new System.Windows.Forms.Label();
            this.presentValueLabel = new System.Windows.Forms.Label();
            this.futureValueInput = new System.Windows.Forms.TextBox();
            this.interestRateInput = new System.Windows.Forms.TextBox();
            this.numYearsInput = new System.Windows.Forms.TextBox();
            this.calculateButton = new System.Windows.Forms.Button();
            this.presentValueOutput = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // futureValueLabel
            // 
            this.futureValueLabel.AutoSize = true;
            this.futureValueLabel.Location = new System.Drawing.Point(31, 28);
            this.futureValueLabel.Name = "futureValueLabel";
            this.futureValueLabel.Size = new System.Drawing.Size(70, 13);
            this.futureValueLabel.TabIndex = 0;
            this.futureValueLabel.Text = "Future Value:";
            // 
            // interestRateLabel
            // 
            this.interestRateLabel.AutoSize = true;
            this.interestRateLabel.Location = new System.Drawing.Point(31, 60);
            this.interestRateLabel.Name = "interestRateLabel";
            this.interestRateLabel.Size = new System.Drawing.Size(107, 13);
            this.interestRateLabel.TabIndex = 1;
            this.interestRateLabel.Text = "Annual Interest Rate:";
            // 
            // numYearsLabel
            // 
            this.numYearsLabel.AutoSize = true;
            this.numYearsLabel.Location = new System.Drawing.Point(31, 94);
            this.numYearsLabel.Name = "numYearsLabel";
            this.numYearsLabel.Size = new System.Drawing.Size(89, 13);
            this.numYearsLabel.TabIndex = 2;
            this.numYearsLabel.Text = "Number of Years:";
            // 
            // presentValueLabel
            // 
            this.presentValueLabel.AutoSize = true;
            this.presentValueLabel.Location = new System.Drawing.Point(31, 128);
            this.presentValueLabel.Name = "presentValueLabel";
            this.presentValueLabel.Size = new System.Drawing.Size(76, 13);
            this.presentValueLabel.TabIndex = 3;
            this.presentValueLabel.Text = "Present Value:";
            // 
            // futureValueInput
            // 
            this.futureValueInput.Location = new System.Drawing.Point(147, 21);
            this.futureValueInput.Name = "futureValueInput";
            this.futureValueInput.Size = new System.Drawing.Size(100, 20);
            this.futureValueInput.TabIndex = 4;
            // 
            // interestRateInput
            // 
            this.interestRateInput.Location = new System.Drawing.Point(147, 53);
            this.interestRateInput.Name = "interestRateInput";
            this.interestRateInput.Size = new System.Drawing.Size(100, 20);
            this.interestRateInput.TabIndex = 5;
            // 
            // numYearsInput
            // 
            this.numYearsInput.Location = new System.Drawing.Point(147, 87);
            this.numYearsInput.Name = "numYearsInput";
            this.numYearsInput.Size = new System.Drawing.Size(100, 20);
            this.numYearsInput.TabIndex = 6;
            // 
            // calculateButton
            // 
            this.calculateButton.Location = new System.Drawing.Point(100, 164);
            this.calculateButton.Name = "calculateButton";
            this.calculateButton.Size = new System.Drawing.Size(75, 23);
            this.calculateButton.TabIndex = 8;
            this.calculateButton.Text = "Calculate";
            this.calculateButton.UseVisualStyleBackColor = true;
            this.calculateButton.Click += new System.EventHandler(this.calculateButton_Click);
            // 
            // presentValueOutput
            // 
            this.presentValueOutput.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.presentValueOutput.Location = new System.Drawing.Point(147, 118);
            this.presentValueOutput.Name = "presentValueOutput";
            this.presentValueOutput.Size = new System.Drawing.Size(100, 23);
            this.presentValueOutput.TabIndex = 9;
            this.presentValueOutput.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Lab7
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(292, 223);
            this.Controls.Add(this.presentValueOutput);
            this.Controls.Add(this.calculateButton);
            this.Controls.Add(this.numYearsInput);
            this.Controls.Add(this.interestRateInput);
            this.Controls.Add(this.futureValueInput);
            this.Controls.Add(this.presentValueLabel);
            this.Controls.Add(this.numYearsLabel);
            this.Controls.Add(this.interestRateLabel);
            this.Controls.Add(this.futureValueLabel);
            this.Name = "Lab7";
            this.Text = "Lab 7";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label futureValueLabel;
        private System.Windows.Forms.Label interestRateLabel;
        private System.Windows.Forms.Label numYearsLabel;
        private System.Windows.Forms.Label presentValueLabel;
        private System.Windows.Forms.TextBox futureValueInput;
        private System.Windows.Forms.TextBox interestRateInput;
        private System.Windows.Forms.TextBox numYearsInput;
        private System.Windows.Forms.Button calculateButton;
        private System.Windows.Forms.Label presentValueOutput;
    }
}


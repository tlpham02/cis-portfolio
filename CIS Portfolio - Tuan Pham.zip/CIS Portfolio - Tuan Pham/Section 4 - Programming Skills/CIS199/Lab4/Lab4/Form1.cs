﻿// W8449
// Lab 4
// February 18, 2018
// 01
// This program is used to determine whether the user is accepted or rejected according to the GPA and test score results.
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab4
{
    public partial class Form1 : Form
    {
        private int calculatorGPA;

        public Form1()
        {
            InitializeComponent();
        }

        private void acceptReject_Click(object sender, EventArgs e)
        {
            if(float.TryParse(currentGPA.Text, out float currentGPAInput) == true && int.TryParse(testScore.Text, out int testScoreInput) == true)
            {
                if(currentGPAInput >= 3.0 && testScoreInput >= 60)
                {
                    MessageBox.Show("Accept");
                    calculatorGPA += 1;
                }
                else if(currentGPAInput < 3.0 && testScoreInput >= 80)
                {
                    MessageBox.Show("Accept");
                    calculatorGPA =+ 1;
                }
                else
                {
                    MessageBox.Show("Reject");
                    calculatorGPA += 1;
                }
                runningTotal.Text = calculatorGPA.ToString();
            }  


        }
    }
}

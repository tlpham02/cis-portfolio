﻿//W8449
// Program 1
// February 13, 2018
// CIS199-01
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Program_1
{
    public partial class Program1 : Form
    {
        public Program1()
        {
            InitializeComponent();
        }

        private void Calculation_Click(object sender, EventArgs e)
        {
            // Declaring variables
            double length; // length of the wall
            double height; // height of the wall
            int doors; // number of doors
            int windows; // number of windows
            int paint; // number of coats of paint
            double gallons; // cost per gallon
            double minGallon; // minimum gallons needed
            double needGallons; // how much gallons we actually need
            double cost; // total cost of paint needed
            const int SUBTRACT_DOORS = 20; // subtract doors from the total square feet
            const int SUBTRACT_WINDOWS = 15; // subtract windows from the total square feet
            const int PAINT_COVER = 375; // total square feet paint can should cover

            
            length = double.Parse(wallLength.Text);
            height = double.Parse(wallHeight.Text);
            doors = int.Parse(doorCount.Text);
            windows = int.Parse(windowCount.Text);
            paint = int.Parse(coatPaint.Text);
            gallons = double.Parse(gallonPaint.Text);

            // Calculations
            minGallon = ((length * height) - (doors * SUBTRACT_DOORS) - (windows * SUBTRACT_WINDOWS) * paint) / (PAINT_COVER);
            needGallons = (int)Math.Ceiling(minGallon);
            cost = gallons * needGallons;

            // Calculation Output
            minPaint.Text = minGallon.ToString("F1");
            gallonsNeeded.Text = needGallons.ToString("F0");
            totalCost.Text = cost.ToString("F2");








            





        }
    }
}

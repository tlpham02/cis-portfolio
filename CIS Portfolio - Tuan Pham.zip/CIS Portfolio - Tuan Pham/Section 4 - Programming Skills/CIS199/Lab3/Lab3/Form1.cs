﻿// W8449
// Lab 3
// February 11, 2018
// 01
// This program is used to calculate the diameter, surface area, and volume of the given radius of the sphere.
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void Radius_TextChanged(object sender, EventArgs e)
        {

        }

        private void calculateRadius_Click(object sender, EventArgs e)
        {
            // Declaring Variables
            double sphereRadius; // Radius of the sphere
            double sphereDiameter; // Diameter of the sphere
            double sphereSurfaceArea; // Surface Area of the sphere
            double sphereVolume; // Volume of the sphere

            sphereRadius = Convert.ToDouble(radiusSphere.Text); // Stating the radius of the sphere

            // Calculations of the radius
            sphereDiameter = 2 * sphereRadius;
            sphereSurfaceArea = 4 * Math.PI * (sphereRadius * sphereRadius);
            sphereVolume = 4 * Math.PI * (sphereRadius * sphereRadius * sphereRadius) / 3;

            // Calculation Output for the radius
            diameterRate.Text = sphereDiameter.ToString("F2");
            surfaceAreaRate.Text = sphereSurfaceArea.ToString("F2");
            volumeRate.Text = sphereVolume.ToString("F2");


        }
    }
}

﻿namespace Program_2
{
    partial class Program2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.creditHourLabel = new System.Windows.Forms.Label();
            this.lastInitialLabel = new System.Windows.Forms.Label();
            this.creditHourInput = new System.Windows.Forms.TextBox();
            this.lastInitialInput = new System.Windows.Forms.TextBox();
            this.dateLabel = new System.Windows.Forms.Label();
            this.timeLabel = new System.Windows.Forms.Label();
            this.dateOutput = new System.Windows.Forms.Label();
            this.timeOutput = new System.Windows.Forms.Label();
            this.checkButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // creditHourLabel
            // 
            this.creditHourLabel.AutoSize = true;
            this.creditHourLabel.Location = new System.Drawing.Point(28, 31);
            this.creditHourLabel.Name = "creditHourLabel";
            this.creditHourLabel.Size = new System.Drawing.Size(184, 13);
            this.creditHourLabel.TabIndex = 0;
            this.creditHourLabel.Text = "Enter Current Amount of Credit Hours:";
            // 
            // lastInitialLabel
            // 
            this.lastInitialLabel.AutoSize = true;
            this.lastInitialLabel.Location = new System.Drawing.Point(127, 76);
            this.lastInitialLabel.Name = "lastInitialLabel";
            this.lastInitialLabel.Size = new System.Drawing.Size(85, 13);
            this.lastInitialLabel.TabIndex = 1;
            this.lastInitialLabel.Text = "Enter Last Initial:";
            // 
            // creditHourInput
            // 
            this.creditHourInput.Location = new System.Drawing.Point(218, 28);
            this.creditHourInput.Name = "creditHourInput";
            this.creditHourInput.Size = new System.Drawing.Size(100, 20);
            this.creditHourInput.TabIndex = 2;
            // 
            // lastInitialInput
            // 
            this.lastInitialInput.Location = new System.Drawing.Point(218, 73);
            this.lastInitialInput.Name = "lastInitialInput";
            this.lastInitialInput.Size = new System.Drawing.Size(100, 20);
            this.lastInitialInput.TabIndex = 3;
            // 
            // dateLabel
            // 
            this.dateLabel.AutoSize = true;
            this.dateLabel.Location = new System.Drawing.Point(73, 177);
            this.dateLabel.Name = "dateLabel";
            this.dateLabel.Size = new System.Drawing.Size(30, 13);
            this.dateLabel.TabIndex = 4;
            this.dateLabel.Text = "Date";
            // 
            // timeLabel
            // 
            this.timeLabel.AutoSize = true;
            this.timeLabel.Location = new System.Drawing.Point(262, 177);
            this.timeLabel.Name = "timeLabel";
            this.timeLabel.Size = new System.Drawing.Size(30, 13);
            this.timeLabel.TabIndex = 5;
            this.timeLabel.Text = "Time";
            // 
            // dateOutput
            // 
            this.dateOutput.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.dateOutput.Location = new System.Drawing.Point(42, 223);
            this.dateOutput.Name = "dateOutput";
            this.dateOutput.Size = new System.Drawing.Size(100, 23);
            this.dateOutput.TabIndex = 6;
            // 
            // timeOutput
            // 
            this.timeOutput.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.timeOutput.Location = new System.Drawing.Point(233, 223);
            this.timeOutput.Name = "timeOutput";
            this.timeOutput.Size = new System.Drawing.Size(100, 23);
            this.timeOutput.TabIndex = 7;
            // 
            // checkButton
            // 
            this.checkButton.Location = new System.Drawing.Point(156, 296);
            this.checkButton.Name = "checkButton";
            this.checkButton.Size = new System.Drawing.Size(75, 23);
            this.checkButton.TabIndex = 8;
            this.checkButton.Text = "Check";
            this.checkButton.UseVisualStyleBackColor = true;
            this.checkButton.Click += new System.EventHandler(this.checkButton_Click);
            // 
            // Program2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(372, 373);
            this.Controls.Add(this.checkButton);
            this.Controls.Add(this.timeOutput);
            this.Controls.Add(this.dateOutput);
            this.Controls.Add(this.timeLabel);
            this.Controls.Add(this.dateLabel);
            this.Controls.Add(this.lastInitialInput);
            this.Controls.Add(this.creditHourInput);
            this.Controls.Add(this.lastInitialLabel);
            this.Controls.Add(this.creditHourLabel);
            this.Name = "Program2";
            this.Text = "Program 2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label creditHourLabel;
        private System.Windows.Forms.Label lastInitialLabel;
        private System.Windows.Forms.TextBox creditHourInput;
        private System.Windows.Forms.TextBox lastInitialInput;
        private System.Windows.Forms.Label dateLabel;
        private System.Windows.Forms.Label timeLabel;
        private System.Windows.Forms.Label dateOutput;
        private System.Windows.Forms.Label timeOutput;
        private System.Windows.Forms.Button checkButton;
    }
}


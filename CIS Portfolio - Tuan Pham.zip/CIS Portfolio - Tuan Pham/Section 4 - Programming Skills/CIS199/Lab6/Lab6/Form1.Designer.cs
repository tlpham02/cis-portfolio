﻿namespace Lab6
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.wordLabel = new System.Windows.Forms.Label();
            this.wordInput = new System.Windows.Forms.TextBox();
            this.gradeOutput = new System.Windows.Forms.Label();
            this.checkGrade = new System.Windows.Forms.Button();
            this.gradeEarned = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // wordLabel
            // 
            this.wordLabel.AutoSize = true;
            this.wordLabel.Location = new System.Drawing.Point(20, 50);
            this.wordLabel.Name = "wordLabel";
            this.wordLabel.Size = new System.Drawing.Size(145, 13);
            this.wordLabel.TabIndex = 0;
            this.wordLabel.Text = "Enter number of words typed:";
            // 
            // wordInput
            // 
            this.wordInput.Location = new System.Drawing.Point(185, 43);
            this.wordInput.Name = "wordInput";
            this.wordInput.Size = new System.Drawing.Size(100, 20);
            this.wordInput.TabIndex = 1;
            // 
            // gradeOutput
            // 
            this.gradeOutput.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.gradeOutput.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.gradeOutput.Location = new System.Drawing.Point(185, 82);
            this.gradeOutput.Name = "gradeOutput";
            this.gradeOutput.Size = new System.Drawing.Size(100, 23);
            this.gradeOutput.TabIndex = 2;
            // 
            // checkGrade
            // 
            this.checkGrade.Location = new System.Drawing.Point(130, 122);
            this.checkGrade.Name = "checkGrade";
            this.checkGrade.Size = new System.Drawing.Size(102, 23);
            this.checkGrade.TabIndex = 3;
            this.checkGrade.Text = "Check Grade";
            this.checkGrade.UseVisualStyleBackColor = true;
            this.checkGrade.Click += new System.EventHandler(this.checkGrade_Click);
            // 
            // gradeEarned
            // 
            this.gradeEarned.AutoSize = true;
            this.gradeEarned.Location = new System.Drawing.Point(89, 92);
            this.gradeEarned.Name = "gradeEarned";
            this.gradeEarned.Size = new System.Drawing.Size(76, 13);
            this.gradeEarned.TabIndex = 4;
            this.gradeEarned.Text = "Grade Earned:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(352, 167);
            this.Controls.Add(this.gradeEarned);
            this.Controls.Add(this.checkGrade);
            this.Controls.Add(this.gradeOutput);
            this.Controls.Add(this.wordInput);
            this.Controls.Add(this.wordLabel);
            this.Name = "Form1";
            this.Text = "Nimble Fingers Typing School";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label wordLabel;
        private System.Windows.Forms.TextBox wordInput;
        private System.Windows.Forms.Label gradeOutput;
        private System.Windows.Forms.Button checkGrade;
        private System.Windows.Forms.Label gradeEarned;
    }
}

